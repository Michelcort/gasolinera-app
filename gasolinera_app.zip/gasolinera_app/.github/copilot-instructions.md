# Copilot Instructions for Gasolinera App

## Project Overview
- **Gasolinera App** is a Progressive Web App (PWA) for managing gas station islands, dispensers, daily readings, deposits, and generating reports.
- Works fully **offline** using service workers and localStorage. Can be installed on mobile devices via "Add to Home Screen".

## Architecture & Key Files
- `index.html`: Main entry point. Loads UI sections for configuration, dispensers, and daily reports. Registers service worker.
- `app.js`: Contains all business logic. Manages islands, dispensers, report generation, and localStorage persistence. UI is dynamically rendered via JS functions.
- `service-worker.js`: Caches all app assets for offline use. Handles fetch events to serve cached files.
- `manifest.json`: PWA manifest for installability and theming.
- `style.css`: Basic styling for UI components.

## Data Flow & State
- **Islands and dispensers** are configured and stored in `localStorage`.
- **Report data** is generated from user input and can be saved as a `.txt` file via browser download.
- No backend or external API calls; all data is local.

## Developer Workflows
- **Run/Debug:**
  - Open `index.html` directly in a browser (Chrome recommended for PWA features).
  - For mobile install, use Chrome (Android) or Safari (iOS) and "Add to Home Screen".
- **Offline Testing:**
  - Ensure service worker is registered (check DevTools > Application > Service Workers).
- **Update Logic/UI:**
  - Edit `app.js` for business rules, UI rendering, and localStorage handling.
  - Edit `index.html` for structure and section layout.
- **Styling:**
  - Edit `style.css` for UI appearance.

## Patterns & Conventions
- **Single JS file** (`app.js`) for all logic; no frameworks used.
- **localStorage** is the only persistence layer.
- **UI sections** are shown/hidden via JS (`mostrarSeccion`).
- **Report generation** is handled in-memory and exported as plain text.
- **Service worker** caches all assets listed in `service-worker.js`.

## Integration Points
- No external dependencies or build steps.
- All files are static and must be present in the root directory.
- App is designed for easy cloning and local use.

## Example: Adding a New Feature
- Add new UI elements in `index.html`.
- Implement logic in `app.js` and update rendering functions.
- Add new assets to cache list in `service-worker.js` if needed.

---
For questions or unclear patterns, review `README.md` and the main JS/HTML files. Ask for feedback if any workflow or pattern is ambiguous.
